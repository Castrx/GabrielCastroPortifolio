import mysql.connector

class BancoDados:
    def __init__(self, user, password, host, database, port=3306):
        self.db_config = {
            'user': user,
            'password': password,
            'host': host,
            'database': database,
            'port': port
        }
        self.conn = mysql.connector.connect(**self.db_config)
        self.cursor = self.conn.cursor()

    def fechar_conexao(self):
        self.conn.close()

    def criar_tabela_contatos(self):
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS contatos (
                id INT PRIMARY KEY AUTO_INCREMENT,
                nome VARCHAR(50),
                perfil_linkedin VARCHAR(50)
            );
        ''')
        self.conn.commit()

    def adicionar_contato(self, nome, perfil_linkedin):
        try:
            self.cursor.execute('SELECT * FROM contatos WHERE perfil_linkedin = %s', (perfil_linkedin,))
            if self.cursor.fetchone() is None:
                self.cursor.execute('INSERT INTO contatos (nome, perfil_linkedin) VALUES (%s, %s)', (nome, perfil_linkedin))
                self.conn.commit()
                print("Contato adicionado com sucesso.")
            else:
                print("Contato já cadastrado.")
        except mysql.connector.Error as erro:
            print(f"Ocorreu um erro {erro}. Tente novamente.")

    def listar_contatos(self):
        try:
            self.cursor.execute('SELECT * FROM contatos')
            contatos = self.cursor.fetchall()
            if contatos:
                print("Lista de contatos:")
                for contato in contatos:
                    print(f"ID: {contato[0]}, Nome: {contato[1]}, Perfil LinkedIn: {contato[2]}")
            else:
                print("Não há contatos cadastrados.")
        except mysql.connector.Error as erro:
            print(f"Ocorreu um erro {erro}. Tente novamente.")

    def excluir_contato(self, contato_id):
        try:
            self.cursor.execute('DELETE FROM contatos WHERE id = %s', (contato_id,))
            if self.cursor.rowcount > 0:
                self.conn.commit()
                print("Contato excluído com sucesso.")
            else:
                print("ID de contato não encontrado.")
        except mysql.connector.Error as erro:
            print(f"Ocorreu um erro {erro}. Tente novamente.")

if __name__ == "__main__":
    db_config = {
        'user':'turma6ntop',
        'password':'turma6ntop',
        'host':'db4free.net',
        'database':'linkedin6n',
        'port':3306
    }

    banco = BancoDados(**db_config)
    banco.criar_tabela_contatos()

    while True:
        print("\nMENU:")
        print("1. Adicionar contato")
        print("2. Listar contatos")
        print("3. Excluir contato")
        print("4. Sair")
        
        opcao = input("Escolha uma opção: ")
        
        if opcao == "1":
            nome = input("Digite o nome do contato: ")
            perfil = input("Digite o perfil do LinkedIn do contato: ")
            banco.adicionar_contato(nome, perfil)
        elif opcao == "2":
            banco.listar_contatos()
        elif opcao == "3":
            contato_id = input("Digite o ID do contato a ser excluído: ")
            banco.excluir_contato(contato_id)
        elif opcao == "4":
            print("Saindo...")
            break
        else:
            print("Opção inválida. Escolha novamente.")

    banco.fechar_conexao()
